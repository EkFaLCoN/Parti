package net.mrwqlf.partysistemi;

/** Uretilmis: panel yazi tipi tablolari (gen_panel2.py). Elle duzenleme. */
final class PanelGlyphs {
    private PanelGlyphs() {}
    static final int ROWS = 7;
    static final int PITCH = 22;
    static final String NAME_CHARS = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789_.-?";
    static final char NAME_BASE = 0xE300;
    static final int[] NAME_ADV = {8, 7, 7, 8, 7, 7, 8, 8, 4, 5, 8, 7, 9, 8, 8, 7, 8, 8, 7, 7, 8, 8, 11, 8, 9, 7, 7, 7, 6, 7, 7, 5, 7, 7, 4, 5, 7, 4, 10, 7, 7, 7, 7, 6, 6, 5, 7, 7, 9, 7, 7, 6, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 6, 4, 5, 6};
    static final String DIGIT_CHARS = "0123456789/+";
    static final char DIGIT_BASE = 0xE600;
    static final int[] DIGIT_ADV = {6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 4, 7};
    static final char CLASS_BASE = 0xE100;
    static final int ICON_ADV = 21;
    static final String[] CLASSES = {"SAVASCI", "SUIKASTCI", "RAHIP", "OKCU", "BUYUCU", "AVCI", "YOK"};
    static final char EFFECT_BASE = 0xE200;
    static final int EFFECT_ADV = 13;
    static final String[] EFFECTS = {"speed", "slowness", "haste", "mining_fatigue", "strength", "jump_boost", "nausea", "regeneration", "resistance", "fire_resistance", "water_breathing", "invisibility", "blindness", "night_vision", "hunger", "weakness", "poison", "wither", "health_boost", "absorption", "saturation", "glowing", "levitation", "luck", "unluck", "slow_falling", "conduit_power", "dolphins_grace", "bad_omen", "hero_of_the_village", "darkness"};
    static final char PLATE = 0xE900;
    static final int PLATE_ADV = 153;
    static final char CAP_L = 0xE800;
    static final char CAP_R = 0xE801;
    static final int CAP_ADV = 8;
    static final char MARK = 0xE700;
    static final int MARK_ADV = 11;
    static final char BAR_BASE = 0xE400;
    static final int BAR_INNER = 100;
    static final int BAR_TRACK_ADV = 103;
}
