package net.mrwqlf.partysistemi;

import net.kyori.adventure.bossbar.BossBar;
import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.event.ClickEvent;
import net.kyori.adventure.text.format.NamedTextColor;
import org.bukkit.Bukkit;
import org.bukkit.attribute.Attribute;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.command.TabCompleter;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.player.PlayerQuitEvent;
import org.bukkit.plugin.java.JavaPlugin;

import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.HashMap;
import java.util.HashSet;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Set;
import java.util.UUID;

/**
 * PartySistemi -- bagimsiz parti eklentisi.
 *
 * - /parti ile en fazla "max-size" kisilik parti
 * - Partideki herkesin canini gosteren kucuk boss barlar
 * - Diger eklentilere KOD BAGIMLILIGI OLMADAN acik API (reflection ile cagrilir):
 *     UUID       getLeaderOf(UUID oyuncu)               -> parti lideri, partide degilse null
 *     List<UUID> getMembersOf(UUID oyuncu)              -> uyeler, partide degilse bos liste
 *     UUID       nextInRotation(UUID oyuncu, Collection<UUID> uygunlar)
 *                                                       -> sirayla bir sonraki uygun uye
 */
public final class PartySistemi extends JavaPlugin implements Listener, CommandExecutor, TabCompleter {

    private static final class Party {
        UUID leader;
        final List<UUID> members = new ArrayList<>();
        int rotation;
    }

    private final Map<UUID, Party> byPlayer = new HashMap<>();
    private final Map<UUID, UUID> invites = new HashMap<>();
    private final Map<UUID, Long> inviteExpiry = new HashMap<>();
    private final Map<UUID, Map<UUID, BossBar>> bars = new HashMap<>();

    private int maxSize = 8;
    private boolean hud = true;
    private net.kyori.adventure.key.Key panelFont;

    @Override
    public void onEnable() {
        saveDefaultConfig();
        maxSize = Math.max(2, getConfig().getInt("max-size", 8));
        hud = getConfig().getBoolean("hud", true);
        String f = getConfig().getString("font", "cursedvalley:party_mid");
        try {
            panelFont = f == null || f.isBlank() ? null : net.kyori.adventure.key.Key.key(f.trim());
        } catch (RuntimeException ex) {
            panelFont = null;
        }
        getServer().getPluginManager().registerEvents(this, this);
        var cmd = getCommand("parti");
        if (cmd != null) {
            cmd.setExecutor(this);
            cmd.setTabCompleter(this);
        }
        getServer().getScheduler().runTaskTimer(this, this::hudTick, 20L, 10L);
        getLogger().info("PartySistemi etkin | en fazla " + maxSize + " kisi");
    }

    @Override
    public void onDisable() {
        clearHud();
    }

    // ==================== ACIK API ====================

    public UUID getLeaderOf(UUID player) {
        Party p = byPlayer.get(player);
        return p == null ? null : p.leader;
    }

    public List<UUID> getMembersOf(UUID player) {
        Party p = byPlayer.get(player);
        return p == null ? Collections.emptyList() : new ArrayList<>(p.members);
    }

    /** Siradaki uygun uyeyi verir ve sirayi ilerletir. Uygun yoksa null. */
    public UUID nextInRotation(UUID player, Collection<UUID> eligible) {
        Party party = byPlayer.get(player);
        if (party == null || eligible == null || eligible.isEmpty()) return null;
        Set<UUID> ok = new HashSet<>(eligible);
        int n = party.members.size();
        for (int i = 0; i < n; i++) {
            int idx = (party.rotation + i) % n;
            UUID id = party.members.get(idx);
            if (ok.contains(id)) {
                party.rotation = (idx + 1) % n;
                return id;
            }
        }
        return null;
    }

    // ==================== HUD (CAN BARLARI) ====================

    public void hudTick() {
        if (!hud) return;
        Set<Party> seen = new LinkedHashSet<>(byPlayer.values());
        Set<UUID> activeViewers = new HashSet<>();

        for (Party party : seen) {
            for (UUID vid : party.members) {
                Player viewer = Bukkit.getPlayer(vid);
                if (viewer == null || !viewer.isOnline()) continue;
                activeViewers.add(vid);
                Map<UUID, BossBar> mine = bars.computeIfAbsent(vid, k -> new HashMap<>());

                Set<UUID> wanted = new HashSet<>();
                for (UUID tid : party.members) {
                    if (tid.equals(vid)) continue;
                    Player t = Bukkit.getPlayer(tid);
                    if (t == null || !t.isOnline()) continue;
                    wanted.add(tid);

                    double max = 20.0;
                    var attr = t.getAttribute(Attribute.MAX_HEALTH);
                    if (attr != null) max = Math.max(1.0, attr.getValue());
                    double hp = Math.max(0.0, t.getHealth());
                    float frac = (float) Math.max(0.0, Math.min(1.0, hp / max));
                    Component title;
                    BossBar.Color color;
                    if (panelFont != null) {
                        // Sol panel gorunumu: sabit genislikli yazi tipi, bar cubugu blok karakterleriyle.
                        int cells = 10;
                        int filled = hp <= 0 ? 0 : Math.max(1, (int) Math.ceil(frac * cells));
                        NamedTextColor hc = frac > 0.5f ? NamedTextColor.GREEN
                                : frac > 0.25f ? NamedTextColor.YELLOW : NamedTextColor.RED;
                        String nm = t.getName();
                        nm = nm.length() > 10 ? nm.substring(0, 10) : String.format("%-10s", nm);
                        title = Component.text(nm + " ", NamedTextColor.WHITE)
                                .append(Component.text("█".repeat(filled), hc))
                                .append(Component.text("█".repeat(cells - filled), NamedTextColor.DARK_GRAY))
                                .append(Component.text(String.format(" %3d", Math.round(hp)), NamedTextColor.GRAY))
                                .font(panelFont);
                        color = BossBar.Color.WHITE;   // pack'te saydam: sadece yazi gorunur
                    } else {
                        title = Component.text(t.getName() + " ", NamedTextColor.WHITE)
                                .append(Component.text("❤ " + Math.round(hp) + "/" + Math.round(max),
                                        NamedTextColor.RED));
                        color = frac > 0.5f ? BossBar.Color.GREEN
                                : frac > 0.25f ? BossBar.Color.YELLOW : BossBar.Color.RED;
                    }

                    BossBar bar = mine.get(tid);
                    if (bar == null) {
                        bar = BossBar.bossBar(title, panelFont != null ? 0f : frac, color, BossBar.Overlay.PROGRESS);
                        mine.put(tid, bar);
                        viewer.showBossBar(bar);
                    } else {
                        bar.name(title);
                        bar.progress(panelFont != null ? 0f : frac);
                        bar.color(color);
                    }
                }
                // Cikan / cevrimdisi olan uyelerin barlarini kaldir.
                for (var it = mine.entrySet().iterator(); it.hasNext(); ) {
                    var en = it.next();
                    if (!wanted.contains(en.getKey())) {
                        viewer.hideBossBar(en.getValue());
                        it.remove();
                    }
                }
            }
        }

        // Artik partisi olmayanlarin barlarini temizle.
        for (var it = bars.entrySet().iterator(); it.hasNext(); ) {
            var en = it.next();
            if (activeViewers.contains(en.getKey())) continue;
            Player v = Bukkit.getPlayer(en.getKey());
            if (v != null) for (BossBar b : en.getValue().values()) v.hideBossBar(b);
            it.remove();
        }
    }

    public void clearHud() {
        for (var en : bars.entrySet()) {
            Player v = Bukkit.getPlayer(en.getKey());
            if (v != null) for (BossBar b : en.getValue().values()) v.hideBossBar(b);
        }
        bars.clear();
    }

    // ==================== PARTI ISLEMLERI ====================

    private void say(CommandSender to, String msg, NamedTextColor color) {
        to.sendMessage(Component.text("[Parti] ", NamedTextColor.GREEN)
                .append(Component.text(msg, color)));
    }

    private void tell(Party party, String msg) {
        for (UUID id : party.members) {
            Player p = Bukkit.getPlayer(id);
            if (p != null) say(p, msg, NamedTextColor.GRAY);
        }
    }

    private Party create(Player leader) {
        Party party = new Party();
        party.leader = leader.getUniqueId();
        party.members.add(leader.getUniqueId());
        byPlayer.put(leader.getUniqueId(), party);
        return party;
    }

    private void leave(UUID id, String reason) {
        Party party = byPlayer.remove(id);
        if (party == null) return;
        party.members.remove(id);
        if (party.members.isEmpty()) return;
        if (party.leader.equals(id)) {
            party.leader = party.members.get(0);
            Player nl = Bukkit.getPlayer(party.leader);
            tell(party, (nl != null ? nl.getName() : "?") + " yeni parti lideri.");
        }
        party.rotation = party.rotation % party.members.size();
        String name = Bukkit.getOfflinePlayer(id).getName();
        tell(party, (name != null ? name : "?") + " " + reason);
        if (party.members.size() == 1) {
            // Tek kisi kalan parti dagitilir.
            byPlayer.remove(party.members.get(0));
            Player last = Bukkit.getPlayer(party.members.get(0));
            if (last != null) say(last, "Parti dağıldı (tek kişi kaldı).", NamedTextColor.GRAY);
        }
    }

    @EventHandler
    public void onQuit(PlayerQuitEvent e) {
        UUID id = e.getPlayer().getUniqueId();
        invites.remove(id);
        inviteExpiry.remove(id);
        bars.remove(id);
        leave(id, "oyundan çıktı ve partiden ayrıldı.");
    }

    @Override
    public boolean onCommand(CommandSender sender, Command cmd, String label, String[] args) {
        if (!(sender instanceof Player me)) {
            sender.sendMessage("Bu komut sadece oyuncular içindir.");
            return true;
        }
        String sub = args.length == 0 ? "yardim" : args[0].toLowerCase(Locale.ROOT);
        Party mine = byPlayer.get(me.getUniqueId());

        switch (sub) {
            case "olustur", "create" -> {
                if (mine != null) { say(me, "Zaten bir partidesin.", NamedTextColor.RED); break; }
                create(me);
                say(me, "Parti kuruldu. /parti davet <oyuncu> ile arkadaşlarını çağır.", NamedTextColor.GREEN);
            }
            case "davet", "invite" -> {
                if (args.length < 2) { say(me, "Kullanım: /parti davet <oyuncu>", NamedTextColor.RED); break; }
                if (mine != null && !mine.leader.equals(me.getUniqueId())) {
                    say(me, "Sadece parti lideri davet edebilir.", NamedTextColor.RED);
                    break;
                }
                if (mine != null && mine.members.size() >= maxSize) {
                    say(me, "Parti dolu (en fazla " + maxSize + " kişi).", NamedTextColor.RED);
                    break;
                }
                Player t = Bukkit.getPlayerExact(args[1]);
                if (t == null) { say(me, "Oyuncu çevrimiçi değil.", NamedTextColor.RED); break; }
                if (t.equals(me)) { say(me, "Kendini davet edemezsin.", NamedTextColor.RED); break; }
                if (byPlayer.containsKey(t.getUniqueId())) {
                    say(me, t.getName() + " zaten bir partide.", NamedTextColor.RED);
                    break;
                }
                if (mine == null) mine = create(me);
                invites.put(t.getUniqueId(), me.getUniqueId());
                inviteExpiry.put(t.getUniqueId(), System.currentTimeMillis() + 60_000L);
                say(me, t.getName() + " davet edildi.", NamedTextColor.GREEN);
                t.sendMessage(Component.text("[Parti] ", NamedTextColor.GREEN)
                        .append(Component.text(me.getName() + " seni partiye çağırıyor. ", NamedTextColor.YELLOW))
                        .append(Component.text("[KABUL]", NamedTextColor.GREEN)
                                .clickEvent(ClickEvent.runCommand("/parti kabul")))
                        .append(Component.text(" "))
                        .append(Component.text("[RED]", NamedTextColor.RED)
                                .clickEvent(ClickEvent.runCommand("/parti reddet"))));
            }
            case "kabul", "accept" -> {
                UUID lid = invites.get(me.getUniqueId());
                Long exp = inviteExpiry.get(me.getUniqueId());
                if (lid == null || exp == null || System.currentTimeMillis() > exp) {
                    say(me, "Bekleyen davetin yok.", NamedTextColor.RED);
                    break;
                }
                invites.remove(me.getUniqueId());
                inviteExpiry.remove(me.getUniqueId());
                if (mine != null) { say(me, "Önce mevcut partinden ayrıl.", NamedTextColor.RED); break; }
                Party target = byPlayer.get(lid);
                if (target == null) { say(me, "Parti artık yok.", NamedTextColor.RED); break; }
                if (target.members.size() >= maxSize) { say(me, "Parti dolu.", NamedTextColor.RED); break; }
                target.members.add(me.getUniqueId());
                byPlayer.put(me.getUniqueId(), target);
                tell(target, me.getName() + " partiye katıldı. (" + target.members.size() + "/" + maxSize + ")");
            }
            case "reddet", "decline" -> {
                UUID lid = invites.remove(me.getUniqueId());
                inviteExpiry.remove(me.getUniqueId());
                if (lid == null) { say(me, "Bekleyen davetin yok.", NamedTextColor.RED); break; }
                Player l = Bukkit.getPlayer(lid);
                if (l != null) say(l, me.getName() + " daveti reddetti.", NamedTextColor.GRAY);
                say(me, "Daveti reddettin.", NamedTextColor.GRAY);
            }
            case "ayril", "leave" -> {
                if (mine == null) { say(me, "Bir partide değilsin.", NamedTextColor.RED); break; }
                leave(me.getUniqueId(), "partiden ayrıldı.");
                say(me, "Partiden ayrıldın.", NamedTextColor.GRAY);
            }
            case "at", "kick" -> {
                if (mine == null || !mine.leader.equals(me.getUniqueId())) {
                    say(me, "Sadece parti lideri atabilir.", NamedTextColor.RED);
                    break;
                }
                if (args.length < 2) { say(me, "Kullanım: /parti at <oyuncu>", NamedTextColor.RED); break; }
                UUID tid = null;
                for (UUID id : mine.members) {
                    String n = Bukkit.getOfflinePlayer(id).getName();
                    if (n != null && n.equalsIgnoreCase(args[1])) tid = id;
                }
                if (tid == null || tid.equals(me.getUniqueId())) {
                    say(me, "Partide böyle bir oyuncu yok.", NamedTextColor.RED);
                    break;
                }
                Player kicked = Bukkit.getPlayer(tid);
                leave(tid, "partiden atıldı.");
                if (kicked != null) say(kicked, "Partiden atıldın.", NamedTextColor.RED);
            }
            case "lider", "promote" -> {
                if (mine == null || !mine.leader.equals(me.getUniqueId())) {
                    say(me, "Sadece parti lideri devredebilir.", NamedTextColor.RED);
                    break;
                }
                if (args.length < 2) { say(me, "Kullanım: /parti lider <oyuncu>", NamedTextColor.RED); break; }
                UUID tid = null;
                for (UUID id : mine.members) {
                    String n = Bukkit.getOfflinePlayer(id).getName();
                    if (n != null && n.equalsIgnoreCase(args[1])) tid = id;
                }
                if (tid == null) { say(me, "Partide böyle bir oyuncu yok.", NamedTextColor.RED); break; }
                mine.leader = tid;
                tell(mine, args[1] + " yeni parti lideri.");
            }
            case "dagit", "disband" -> {
                if (mine == null || !mine.leader.equals(me.getUniqueId())) {
                    say(me, "Sadece parti lideri dağıtabilir.", NamedTextColor.RED);
                    break;
                }
                tell(mine, "Parti dağıtıldı.");
                for (UUID id : new ArrayList<>(mine.members)) byPlayer.remove(id);
            }
            case "liste", "list" -> {
                if (mine == null) { say(me, "Bir partide değilsin.", NamedTextColor.RED); break; }
                StringBuilder sb = new StringBuilder();
                for (UUID id : mine.members) {
                    String n = Bukkit.getOfflinePlayer(id).getName();
                    if (sb.length() > 0) sb.append(", ");
                    sb.append(n != null ? n : "?");
                    if (id.equals(mine.leader)) sb.append(" ★");
                }
                say(me, "Üyeler (" + mine.members.size() + "/" + maxSize + "): " + sb, NamedTextColor.YELLOW);
            }
            default -> {
                say(me, "/parti olustur | davet <oyuncu> | kabul | reddet | ayril | liste", NamedTextColor.YELLOW);
                say(me, "Lider: /parti at <oyuncu> | lider <oyuncu> | dagit", NamedTextColor.GRAY);
            }
        }
        return true;
    }

    @Override
    public List<String> onTabComplete(CommandSender s, Command c, String l, String[] a) {
        List<String> out = new ArrayList<>();
        if (a.length == 1) {
            for (String x : List.of("olustur", "davet", "kabul", "reddet", "ayril", "liste", "at", "lider", "dagit")) {
                if (x.startsWith(a[0].toLowerCase(Locale.ROOT))) out.add(x);
            }
        } else if (a.length == 2 && List.of("davet", "at", "lider").contains(a[0].toLowerCase(Locale.ROOT))) {
            for (Player p : Bukkit.getOnlinePlayers()) {
                if (p.getName().toLowerCase(Locale.ROOT).startsWith(a[1].toLowerCase(Locale.ROOT))) out.add(p.getName());
            }
        }
        return out;
    }
}
