package net.mrwqlf.partysistemi;

import net.kyori.adventure.bossbar.BossBar;
import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.event.ClickEvent;
import net.kyori.adventure.text.format.NamedTextColor;
import org.bukkit.Bukkit;
import org.bukkit.attribute.Attribute;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.command.TabCompleter;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.player.PlayerQuitEvent;
import org.bukkit.plugin.java.JavaPlugin;

import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.HashMap;
import java.util.HashSet;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Set;
import java.util.UUID;

/**
 * PartySistemi -- bagimsiz parti eklentisi.
 *
 * - /parti ile en fazla "max-size" kisilik parti
 * - Partideki herkesin canini gosteren kucuk boss barlar
 * - Diger eklentilere KOD BAGIMLILIGI OLMADAN acik API (reflection ile cagrilir):
 *     UUID       getLeaderOf(UUID oyuncu)               -> parti lideri, partide degilse null
 *     List<UUID> getMembersOf(UUID oyuncu)              -> uyeler, partide degilse bos liste
 *     UUID       nextInRotation(UUID oyuncu, Collection<UUID> uygunlar)
 *                                                       -> sirayla bir sonraki uygun uye
 */
public final class PartySistemi extends JavaPlugin implements Listener, CommandExecutor, TabCompleter {

    private static final class Party {
        UUID leader;
        final List<UUID> members = new ArrayList<>();
        int rotation;
    }

    private final Map<UUID, Party> byPlayer = new HashMap<>();
    private final Map<UUID, UUID> invites = new HashMap<>();
    private final Map<UUID, Long> inviteExpiry = new HashMap<>();
    private final Map<UUID, Map<UUID, BossBar>> bars = new HashMap<>();

    private int maxSize = 8;
    private boolean hud = true;
    private boolean panel = true;
    private final Map<UUID, UUID> targets = new HashMap<>();   // kenetleyen -> hedef
    private String targetClick = "sneak";
    private double targetRange = 20.0;
    private int panelOffset = 280;

    @Override
    public void onEnable() {
        saveDefaultConfig();
        maxSize = Math.max(2, getConfig().getInt("max-size", 8));
        hud = getConfig().getBoolean("hud", true);
        sameRaceOnly = getConfig().getBoolean("same-race-only", true);
        panel = getConfig().getBoolean("panel", true);
        targetRange = Math.max(3.0, getConfig().getDouble("target-range", 20.0));
        targetClick = String.valueOf(getConfig().getString("target-click", "sneak")).toLowerCase(Locale.ROOT);
        panelOffset = Math.max(40, getConfig().getInt("panel-offset", 280));
        getServer().getPluginManager().registerEvents(this, this);
        var cmd = getCommand("parti");
        if (cmd != null) {
            cmd.setExecutor(this);
            cmd.setTabCompleter(this);
        }
        getServer().getScheduler().runTaskTimer(this, this::hudTick, 20L, 10L);
        getLogger().info("PartySistemi etkin | en fazla " + maxSize + " kisi");
    }

    @Override
    public void onDisable() {
        clearHud();
    }

    // ==================== IRK KONTROLU ====================

    private boolean sameRaceOnly = true;
    private int raceTick;

    /** ClassAndRegion kuruluysa oyuncunun irki (EMBERON/RHODAR); irki yoksa veya eklenti yoksa null. */
    private String raceOf(UUID id) {
        try {
            var pl = Bukkit.getPluginManager().getPlugin("ClassAndRegion");
            if (pl == null || !pl.isEnabled()) return null;
            Object sistem = pl.getClass().getMethod("getIrkSistemi").invoke(pl);
            if (sistem == null) return null;
            Object irk = sistem.getClass().getMethod("getIrk", UUID.class).invoke(sistem, id);
            return irk == null ? null : ((Enum<?>) irk).name();
        } catch (ReflectiveOperationException | RuntimeException ex) {
            return null;
        }
    }

    private boolean raceSystemPresent() {
        var pl = Bukkit.getPluginManager().getPlugin("ClassAndRegion");
        return pl != null && pl.isEnabled();
    }

    /** Iki oyuncu ayni partide olabilir mi? (irk sistemi yoksa her zaman evet) */
    private boolean compatible(UUID a, UUID b) {
        if (!sameRaceOnly || !raceSystemPresent()) return true;
        String ra = raceOf(a), rb = raceOf(b);
        return java.util.Objects.equals(ra, rb);
    }

    /** Irki sonradan degisen / uyumsuz kalan uyeleri partiden cikarir. */
    private void checkRaces() {
        if (!sameRaceOnly || !raceSystemPresent()) return;
        for (Party party : new LinkedHashSet<>(byPlayer.values())) {
            for (UUID id : new ArrayList<>(party.members)) {
                if (id.equals(party.leader)) continue;
                if (!compatible(id, party.leader)) {
                    Player p = Bukkit.getPlayer(id);
                    leave(id, "ırkı farklı olduğu için partiden çıkarıldı.");
                    if (p != null) say(p, "Irkın lider ile aynı değil, partiden çıkarıldın.", NamedTextColor.RED);
                }
            }
        }
    }

    // ==================== ACIK API ====================

    public UUID getLeaderOf(UUID player) {
        Party p = byPlayer.get(player);
        return p == null ? null : p.leader;
    }

    public List<UUID> getMembersOf(UUID player) {
        Party p = byPlayer.get(player);
        return p == null ? Collections.emptyList() : new ArrayList<>(p.members);
    }

    /** Oyuncunun kenetlendigi (hedefledigi) parti uyesi; yoksa null. Rahip sifasi gibi yetenekler bunu kullanir. */
    public UUID getTargetOf(UUID selector) {
        UUID t = targets.get(selector);
        if (t == null) return null;
        Party a = byPlayer.get(selector), b = byPlayer.get(t);
        if (a == null || a != b) {
            targets.remove(selector);
            return null;
        }
        return t;
    }

    /** Kenetle / ayril (ayni hedefe tekrar basinca birakir). */
    private void toggleTarget(Player me, UUID target) {
        Party a = byPlayer.get(me.getUniqueId());
        if (a == null || byPlayer.get(target) != a || target.equals(me.getUniqueId())) return;
        String nm = Bukkit.getOfflinePlayer(target).getName();
        if (target.equals(targets.get(me.getUniqueId()))) {
            targets.remove(me.getUniqueId());
            me.sendActionBar(Component.text("Kenetleme bırakıldı: " + (nm != null ? nm : "?"), NamedTextColor.GRAY));
            me.playSound(me.getLocation(), org.bukkit.Sound.UI_BUTTON_CLICK, 0.6f, 0.8f);
        } else {
            targets.put(me.getUniqueId(), target);
            me.sendActionBar(Component.text("Kenetlendin: " + (nm != null ? nm : "?"), NamedTextColor.GOLD));
            me.playSound(me.getLocation(), org.bukkit.Sound.BLOCK_NOTE_BLOCK_CHIME, 0.7f, 1.6f);
        }
    }

    /** Siradaki uygun uyeyi verir ve sirayi ilerletir. Uygun yoksa null. */
    public UUID nextInRotation(UUID player, Collection<UUID> eligible) {
        Party party = byPlayer.get(player);
        if (party == null || eligible == null || eligible.isEmpty()) return null;
        Set<UUID> ok = new HashSet<>(eligible);
        int n = party.members.size();
        for (int i = 0; i < n; i++) {
            int idx = (party.rotation + i) % n;
            UUID id = party.members.get(idx);
            if (ok.contains(id)) {
                party.rotation = (idx + 1) % n;
                return id;
            }
        }
        return null;
    }

    // ==================== HUD (SOL PANEL) ====================

    private static final net.kyori.adventure.key.Key SPACE_FONT = net.kyori.adventure.key.Key.key("cursedvalley:pp_sp");
    private static final net.kyori.adventure.key.Key[] ROW_FONT = new net.kyori.adventure.key.Key[PanelGlyphs.ROWS];
    static {
        for (int i = 0; i < ROW_FONT.length; i++) ROW_FONT[i] = net.kyori.adventure.key.Key.key("cursedvalley:pp_r" + i);
    }

    /** Boslukluk fontu: n piksel ilerle (negatif = geri). */
    private static String sp(int n) {
        if (n == 0) return "";
        StringBuilder sb = new StringBuilder();
        char base = n > 0 ? '\uE000' : '\uE010';
        int v = Math.abs(n);
        for (int bit = 9; bit >= 0; bit--) {
            int w = 1 << bit;
            while (v >= w) {
                sb.append((char) (base + bit));
                v -= w;
            }
        }
        return sb.toString();
    }

    private static Component spc(int n) {
        return n == 0 ? Component.empty() : Component.text(sp(n)).font(SPACE_FONT);
    }

    private static Component seg(String text, int row, net.kyori.adventure.text.format.TextColor color) {
        return Component.text(text).font(ROW_FONT[row]).color(color);
    }

    private static int nameAdvance(char c) {
        int i = PanelGlyphs.NAME_CHARS.indexOf(c);
        return PanelGlyphs.NAME_ADV[i < 0 ? PanelGlyphs.NAME_CHARS.indexOf('?') : i];
    }

    /** ClassAndRegion kuruluysa oyuncunun sinifi (SAVASCI...); yoksa null. */
    private String classOf(UUID id) {
        try {
            var pl = Bukkit.getPluginManager().getPlugin("ClassAndRegion");
            if (pl == null || !pl.isEnabled()) return null;
            Object depo = pl.getClass().getMethod("getDepo").invoke(pl);
            if (depo == null) return null;
            Object sinif = depo.getClass().getMethod("getSinif", UUID.class).invoke(depo, id);
            return sinif == null ? null : ((Enum<?>) sinif).name();
        } catch (ReflectiveOperationException | RuntimeException ex) {
            return null;
        }
    }

    /** Siniftan gorunen ad (Savasci, Okcu...). */
    private String classLabel(UUID id) {
        try {
            var pl = Bukkit.getPluginManager().getPlugin("ClassAndRegion");
            if (pl == null || !pl.isEnabled()) return "-";
            Object depo = pl.getClass().getMethod("getDepo").invoke(pl);
            Object sinif = depo.getClass().getMethod("getSinif", UUID.class).invoke(depo, id);
            if (sinif == null) return "-";
            return (String) sinif.getClass().getMethod("ad").invoke(sinif);
        } catch (ReflectiveOperationException | RuntimeException ex) {
            return "-";
        }
    }

    private static char classChar(String cls) {
        int idx = PanelGlyphs.CLASSES.length - 1;     // YOK
        if (cls != null) {
            for (int i = 0; i < PanelGlyphs.CLASSES.length; i++) {
                if (PanelGlyphs.CLASSES[i].equals(cls)) idx = i;
            }
        }
        return (char) (PanelGlyphs.CLASS_BASE + idx);
    }

    private static String effectKey(org.bukkit.potion.PotionEffectType t) {
        return t.getKey().getKey();
    }

    /** Bir uyenin panel satiri (blok r). */
    private Component block(Player t, int r, UUID viewerId) {
        double max = 20.0;
        var attr = t.getAttribute(Attribute.MAX_HEALTH);
        if (attr != null) max = Math.max(1.0, attr.getValue());
        double hp = Math.max(0.0, t.getHealth());
        double frac = Math.max(0.0, Math.min(1.0, hp / max));
        int k = hp <= 0 ? 0 : Math.max(1, (int) Math.round(frac * PanelGlyphs.BAR_INNER));
        net.kyori.adventure.text.format.TextColor hc = frac > 0.5 ? net.kyori.adventure.text.format.TextColor.color(0x44DD55)
                : frac > 0.25 ? net.kyori.adventure.text.format.TextColor.color(0xFFD23C)
                : net.kyori.adventure.text.format.TextColor.color(0xFF4040);

        Component out = Component.empty();
        int x = 0;
        // 1) sinif simgesi (20 + 1)
        out = out.append(seg(String.valueOf(classChar(classOf(t.getUniqueId()))), r, NamedTextColor.WHITE));
        x += PanelGlyphs.ICON_ADV;
        // arka plaka (en altta kalsin diye ilk cizilir), sonra geri sar
        out = out.append(seg(String.valueOf(PanelGlyphs.PLATE), r, NamedTextColor.WHITE));
        out = out.append(spc(-PanelGlyphs.PLATE_ADV));
        out = out.append(spc(2));
        x += 2;
        int x0 = x;                                                // isim / cubuk sol kenari

        // 2) can cubugu: iz, geri sar, dolgu (her % ayri), geri sar
        boolean locked = viewerId != null && t.getUniqueId().equals(targets.get(viewerId));
        char track = locked ? (char) (PanelGlyphs.BAR_BASE + PanelGlyphs.BAR_INNER + 1) : PanelGlyphs.BAR_BASE;
        out = out.append(seg(String.valueOf(track), r, NamedTextColor.WHITE));
        out = out.append(spc(-PanelGlyphs.BAR_TRACK_ADV));
        if (k > 0) {
            out = out.append(spc(1));
            out = out.append(seg(String.valueOf((char) (PanelGlyphs.BAR_BASE + k)), r, hc));
            out = out.append(spc(-(2 + k)));
        }

        // 2b) can yazisi cubugun uzerinde ortali: "17/20"
        double abs = Math.max(0.0, t.getAbsorptionAmount());
        String hpText = Math.round(hp) + "/" + Math.round(max) + (abs >= 0.5 ? "+" + Math.round(abs) : "");
        StringBuilder dg = new StringBuilder();
        int dw = 0;
        for (char c : hpText.toCharArray()) {
            int i = PanelGlyphs.DIGIT_CHARS.indexOf(c);
            if (i < 0) continue;
            dg.append((char) (PanelGlyphs.DIGIT_BASE + i));
            dw += PanelGlyphs.DIGIT_ADV[i];
        }
        int pad = Math.max(0, (PanelGlyphs.BAR_INNER + 2 - dw) / 2);
        out = out.append(spc(pad));
        out = out.append(seg(dg.toString(), r, NamedTextColor.WHITE));
        out = out.append(spc(-(pad + dw)));
        // bar uc susleri (altin kanat): iz 2 px disina taşar
        out = out.append(spc(-2));
        out = out.append(seg(String.valueOf(PanelGlyphs.CAP_L), r, NamedTextColor.WHITE));
        out = out.append(spc(-(PanelGlyphs.CAP_ADV - 2)));
        int capR = PanelGlyphs.BAR_INNER - 4;                       // 96
        out = out.append(spc(capR + 1));
        out = out.append(seg(String.valueOf(PanelGlyphs.CAP_R), r, NamedTextColor.WHITE));
        out = out.append(spc(-(capR + 1 + PanelGlyphs.CAP_ADV)));
        if (locked) {
            int mx = PanelGlyphs.BAR_TRACK_ADV + 2;
            out = out.append(spc(mx));
            out = out.append(seg(String.valueOf(PanelGlyphs.MARK), r, NamedTextColor.WHITE));
            out = out.append(spc(-(mx + PanelGlyphs.MARK_ADV)));
        }

        // 3) isim (en fazla 12 harf)
        String nm = t.getName();
        if (nm.length() > 12) nm = nm.substring(0, 12);
        StringBuilder chars = new StringBuilder();
        int nameW = 0;
        for (char c : nm.toCharArray()) {
            int i = PanelGlyphs.NAME_CHARS.indexOf(c);
            if (i < 0) { c = '?'; i = PanelGlyphs.NAME_CHARS.indexOf('?'); }
            chars.append((char) (PanelGlyphs.NAME_BASE + i));
            nameW += PanelGlyphs.NAME_ADV[i];
        }
        out = out.append(seg(chars.toString(), r, locked ? NamedTextColor.GOLD : NamedTextColor.WHITE));
        x += nameW;

        // 4) efekt ikonlari (en fazla 5; suresiz anlik etkiler yok)
        StringBuilder eff = new StringBuilder();
        int n = 0;
        for (var pe : t.getActivePotionEffects()) {
            if (n >= 5) break;
            String key = effectKey(pe.getType());
            for (int i = 0; i < PanelGlyphs.EFFECTS.length; i++) {
                if (PanelGlyphs.EFFECTS[i].equals(key)) {
                    eff.append((char) (PanelGlyphs.EFFECT_BASE + i));
                    n++;
                    break;
                }
            }
        }
        if (n > 0) {
            out = out.append(spc(3));
            out = out.append(seg(eff.toString(), r, NamedTextColor.WHITE));
            x += 3 + n * PanelGlyphs.EFFECT_ADV;
        }
        // 5) blok basina don
        return out.append(spc(-x));
    }

    private Component panelTitle(Player viewer, Party party) {
        Component out = Component.empty();
        int r = 0;
        for (UUID tid : party.members) {
            if (tid.equals(viewer.getUniqueId())) continue;
            Player t = Bukkit.getPlayer(tid);
            if (t == null || !t.isOnline()) continue;
            if (r >= PanelGlyphs.ROWS) break;
            out = out.append(block(t, r, viewer.getUniqueId()));
            r++;
        }
        if (r == 0) return null;
        // Baslik ortalanir: toplam ilerleme 2*panelOffset olsun -> panel ekran ortasindan panelOffset solda baslar.
        return out.append(spc(2 * panelOffset));
    }

    public void hudTick() {
        if (++raceTick >= 20) { raceTick = 0; checkRaces(); }
        // Kenet gecerliligi + sadece kenetleyene gorunen isaret
        for (var it = targets.entrySet().iterator(); it.hasNext(); ) {
            var en = it.next();
            if (getTargetOf(en.getKey()) == null) { it.remove(); continue; }
            Player sel = Bukkit.getPlayer(en.getKey()), tg = Bukkit.getPlayer(en.getValue());
            if (sel != null && tg != null && sel.getWorld().equals(tg.getWorld())
                    && sel.getLocation().distanceSquared(tg.getLocation()) < 48 * 48) {
                sel.spawnParticle(org.bukkit.Particle.END_ROD, tg.getLocation().add(0, 2.35, 0), 1, 0.12, 0.05, 0.12, 0.0);
            }
        }
        if (!hud) return;
        Set<Party> seen = new LinkedHashSet<>(byPlayer.values());
        Set<UUID> activeViewers = new HashSet<>();

        for (Party party : seen) {
            for (UUID vid : party.members) {
                Player viewer = Bukkit.getPlayer(vid);
                if (viewer == null || !viewer.isOnline()) continue;
                activeViewers.add(vid);
                Map<UUID, BossBar> mine = bars.computeIfAbsent(vid, k -> new HashMap<>());
                Set<UUID> wanted = new HashSet<>();

                if (panel) {
                    // Tek boss bar: tum uyeler ust uste satirlar halinde cizilir.
                    Component title = panelTitle(viewer, party);
                    if (title != null) {
                        wanted.add(vid);
                        BossBar bar = mine.get(vid);
                        if (bar == null) {
                            bar = BossBar.bossBar(title, 0f, BossBar.Color.WHITE, BossBar.Overlay.PROGRESS);
                            mine.put(vid, bar);
                            viewer.showBossBar(bar);
                        } else {
                            bar.name(title);
                        }
                    }
                } else {
                    // Klasik: her uye icin ayri renkli boss bar (texturepack gerekmez).
                    for (UUID tid : party.members) {
                        if (tid.equals(vid)) continue;
                        Player t = Bukkit.getPlayer(tid);
                        if (t == null || !t.isOnline()) continue;
                        wanted.add(tid);
                        double max = 20.0;
                        var attr = t.getAttribute(Attribute.MAX_HEALTH);
                        if (attr != null) max = Math.max(1.0, attr.getValue());
                        double hp = Math.max(0.0, t.getHealth());
                        float frac = (float) Math.max(0.0, Math.min(1.0, hp / max));
                        Component title = Component.text(t.getName() + " ", NamedTextColor.WHITE)
                                .append(Component.text("❤ " + Math.round(hp) + "/" + Math.round(max), NamedTextColor.RED));
                        BossBar.Color color = frac > 0.5f ? BossBar.Color.GREEN
                                : frac > 0.25f ? BossBar.Color.YELLOW : BossBar.Color.RED;
                        BossBar bar = mine.get(tid);
                        if (bar == null) {
                            bar = BossBar.bossBar(title, frac, color, BossBar.Overlay.PROGRESS);
                            mine.put(tid, bar);
                            viewer.showBossBar(bar);
                        } else {
                            bar.name(title);
                            bar.progress(frac);
                            bar.color(color);
                        }
                    }
                }
                for (var it = mine.entrySet().iterator(); it.hasNext(); ) {
                    var en = it.next();
                    if (!wanted.contains(en.getKey())) {
                        viewer.hideBossBar(en.getValue());
                        it.remove();
                    }
                }
            }
        }

        for (var it = bars.entrySet().iterator(); it.hasNext(); ) {
            var en = it.next();
            if (activeViewers.contains(en.getKey())) continue;
            Player v = Bukkit.getPlayer(en.getKey());
            if (v != null) for (BossBar b : en.getValue().values()) v.hideBossBar(b);
            it.remove();
        }
    }

    public void clearHud() {
        for (var en : bars.entrySet()) {
            Player v = Bukkit.getPlayer(en.getKey());
            if (v != null) for (BossBar b : en.getValue().values()) v.hideBossBar(b);
        }
        bars.clear();
    }

    // ==================== PARTI MENUSU (EFEKT SURELERI) ====================

    /** Menu envanteri; icindeki esyalarin ustune gelince / dokununca efekt suresi gorunur. */
    private static final class MenuHolder implements org.bukkit.inventory.InventoryHolder {
        org.bukkit.inventory.Inventory inv;
        public org.bukkit.inventory.Inventory getInventory() { return inv; }
    }

    private void openMenu(Player me, Party party) {
        MenuHolder h = new MenuHolder();
        h.inv = Bukkit.createInventory(h, 9 * Math.max(1, Math.min(6, party.members.size())),
                Component.text("Parti (" + party.members.size() + "/" + maxSize + ")", NamedTextColor.DARK_GREEN));
        fillMenu(h.inv, party, me.getUniqueId());
        me.openInventory(h.inv);
        // Acikken her saniye tazele: kalan sureler akar.
        getServer().getScheduler().runTaskTimer(this, task -> {
            if (!me.isOnline() || me.getOpenInventory().getTopInventory() != h.inv) {
                task.cancel();
                return;
            }
            fillMenu(h.inv, party, me.getUniqueId());
        }, 20L, 20L);
    }

    private void fillMenu(org.bukkit.inventory.Inventory inv, Party party, UUID viewerId) {
        inv.clear();
        int row = 0;
        for (UUID id : party.members) {
            if (row >= inv.getSize() / 9) break;
            Player t = Bukkit.getPlayer(id);
            int base = row * 9;
            var head = new org.bukkit.inventory.ItemStack(org.bukkit.Material.PLAYER_HEAD);
            var sm = (org.bukkit.inventory.meta.SkullMeta) head.getItemMeta();
            sm.setOwningPlayer(Bukkit.getOfflinePlayer(id));
            String nm = Bukkit.getOfflinePlayer(id).getName();
            sm.displayName(Component.text(nm != null ? nm : "?", id.equals(party.leader)
                    ? NamedTextColor.GOLD : NamedTextColor.WHITE)
                    .decoration(net.kyori.adventure.text.format.TextDecoration.ITALIC, false));
            List<Component> lore = new ArrayList<>();
            lore.add(Component.text("Sınıf: " + classLabel(id), NamedTextColor.GRAY)
                    .decoration(net.kyori.adventure.text.format.TextDecoration.ITALIC, false));
            if (t != null && t.isOnline()) {
                lore.add(Component.text("Can: " + Math.round(t.getHealth()), NamedTextColor.RED)
                        .decoration(net.kyori.adventure.text.format.TextDecoration.ITALIC, false));
            } else {
                lore.add(Component.text("Çevrimdışı", NamedTextColor.DARK_GRAY)
                        .decoration(net.kyori.adventure.text.format.TextDecoration.ITALIC, false));
            }
            if (!id.equals(viewerId)) {
                lore.add(Component.text(id.equals(getTargetOf(viewerId)) ? "★ Kenetli — tıkla: bırak" : "Tıkla: kenetlen",
                        NamedTextColor.GOLD).decoration(net.kyori.adventure.text.format.TextDecoration.ITALIC, false));
            }
            sm.lore(lore);
            head.setItemMeta(sm);
            inv.setItem(base, head);

            if (t != null && t.isOnline()) {
                int slot = base + 1;
                for (var pe : t.getActivePotionEffects()) {
                    if (slot >= base + 9) break;
                    var it = new org.bukkit.inventory.ItemStack(org.bukkit.Material.PAPER);
                    var m = it.getItemMeta();
                    String key = effectKey(pe.getType());
                    Component title = Component.translatable("effect.minecraft." + key)
                            .append(Component.text(" " + (pe.getAmplifier() + 1)))
                            .color(NamedTextColor.AQUA)
                            .decoration(net.kyori.adventure.text.format.TextDecoration.ITALIC, false);
                    m.displayName(title);
                    int sec = pe.getDuration() < 0 ? -1 : pe.getDuration() / 20;
                    String left = sec < 0 ? "Sonsuz" : String.format("%d:%02d", sec / 60, sec % 60);
                    m.lore(List.of(Component.text("Kalan süre: " + left, NamedTextColor.YELLOW)
                            .decoration(net.kyori.adventure.text.format.TextDecoration.ITALIC, false)));
                    it.setItemMeta(m);
                    inv.setItem(slot++, it);
                }
            }
            row++;
        }
    }

    @EventHandler
    public void onMenuClick(org.bukkit.event.inventory.InventoryClickEvent e) {
        if (!(e.getView().getTopInventory().getHolder() instanceof MenuHolder)) return;
        e.setCancelled(true);
        // Uyenin kafasina tiklayinca kenetle / birak
        if (e.getClickedInventory() == e.getView().getTopInventory() && e.getRawSlot() % 9 == 0
                && e.getWhoClicked() instanceof Player me) {
            Party party = byPlayer.get(me.getUniqueId());
            int row = e.getRawSlot() / 9;
            if (party != null && row < party.members.size()) toggleTarget(me, party.members.get(row));
        }
    }

    private final Map<UUID, Long> lastTargetClick = new HashMap<>();

    /** Cok tetiklenmesin (ayni tik hem entity hem hava olayi uretebilir). */
    private boolean debounce(Player p) {
        long now = System.currentTimeMillis();
        Long last = lastTargetClick.get(p.getUniqueId());
        if (last != null && now - last < 250) return true;
        lastTargetClick.put(p.getUniqueId(), now);
        return false;
    }

    /** UZAKTAN kenetleme: partideki birine bakip (varsayilan comelerek) sag tikla. */
    @EventHandler
    public void onFarTarget(org.bukkit.event.player.PlayerInteractEvent e) {
        if (e.getHand() != org.bukkit.inventory.EquipmentSlot.HAND) return;
        var act = e.getAction();
        if (act != org.bukkit.event.block.Action.RIGHT_CLICK_AIR
                && act != org.bukkit.event.block.Action.RIGHT_CLICK_BLOCK) return;
        if (targetClick.equals("off")) return;
        Player me = e.getPlayer();
        if (targetClick.equals("sneak") && !me.isSneaking()) return;
        Party party = byPlayer.get(me.getUniqueId());
        if (party == null) return;

        var eye = me.getEyeLocation();
        var dir = eye.getDirection();
        var hit = me.getWorld().rayTraceEntities(eye, dir, targetRange, 0.7, en ->
                en instanceof Player pl && !pl.equals(me) && byPlayer.get(pl.getUniqueId()) == party);
        if (hit == null || !(hit.getHitEntity() instanceof Player other)) return;
        double d = hit.getHitPosition().distance(eye.toVector());
        var wall = me.getWorld().rayTraceBlocks(eye, dir, d, org.bukkit.FluidCollisionMode.NEVER, true);
        if (wall != null) return;
        e.setCancelled(true);
        if (debounce(me)) return;
        toggleTarget(me, other.getUniqueId());
    }

    /** Yakindan: partideki birine (varsayilan: comelerek) sag tiklayinca kenetle / birak. */
    @EventHandler
    public void onTargetClick(org.bukkit.event.player.PlayerInteractEntityEvent e) {
        if (e.getHand() != org.bukkit.inventory.EquipmentSlot.HAND) return;
        if (targetClick.equals("off")) return;
        if (!(e.getRightClicked() instanceof Player other)) return;
        Player me = e.getPlayer();
        if (targetClick.equals("sneak") && !me.isSneaking()) return;
        Party a = byPlayer.get(me.getUniqueId());
        if (a == null || byPlayer.get(other.getUniqueId()) != a) return;
        e.setCancelled(true);
        if (debounce(me)) return;
        toggleTarget(me, other.getUniqueId());
    }

    @EventHandler
    public void onMenuDrag(org.bukkit.event.inventory.InventoryDragEvent e) {
        if (e.getView().getTopInventory().getHolder() instanceof MenuHolder) e.setCancelled(true);
    }

    // ==================== PARTI ISLEMLERI ====================

    private void say(CommandSender to, String msg, NamedTextColor color) {
        to.sendMessage(Component.text("[Parti] ", NamedTextColor.GREEN)
                .append(Component.text(msg, color)));
    }

    private void tell(Party party, String msg) {
        for (UUID id : party.members) {
            Player p = Bukkit.getPlayer(id);
            if (p != null) say(p, msg, NamedTextColor.GRAY);
        }
    }

    private Party create(Player leader) {
        Party party = new Party();
        party.leader = leader.getUniqueId();
        party.members.add(leader.getUniqueId());
        byPlayer.put(leader.getUniqueId(), party);
        return party;
    }

    private void leave(UUID id, String reason) {
        targets.remove(id);
        targets.values().removeIf(v -> v.equals(id));
        Party party = byPlayer.remove(id);
        if (party == null) return;
        party.members.remove(id);
        if (party.members.isEmpty()) return;
        if (party.leader.equals(id)) {
            party.leader = party.members.get(0);
            Player nl = Bukkit.getPlayer(party.leader);
            tell(party, (nl != null ? nl.getName() : "?") + " yeni parti lideri.");
        }
        party.rotation = party.rotation % party.members.size();
        String name = Bukkit.getOfflinePlayer(id).getName();
        tell(party, (name != null ? name : "?") + " " + reason);
        if (party.members.size() == 1) {
            // Tek kisi kalan parti dagitilir.
            byPlayer.remove(party.members.get(0));
            Player last = Bukkit.getPlayer(party.members.get(0));
            if (last != null) say(last, "Parti dağıldı (tek kişi kaldı).", NamedTextColor.GRAY);
        }
    }

    @EventHandler
    public void onQuit(PlayerQuitEvent e) {
        UUID id = e.getPlayer().getUniqueId();
        invites.remove(id);
        inviteExpiry.remove(id);
        bars.remove(id);
        leave(id, "oyundan çıktı ve partiden ayrıldı.");
    }

    @Override
    public boolean onCommand(CommandSender sender, Command cmd, String label, String[] args) {
        if (!(sender instanceof Player me)) {
            sender.sendMessage("Bu komut sadece oyuncular içindir.");
            return true;
        }
        String sub = args.length == 0 ? (byPlayer.containsKey(me.getUniqueId()) ? "menu" : "yardim") : args[0].toLowerCase(Locale.ROOT);
        Party mine = byPlayer.get(me.getUniqueId());

        switch (sub) {
            case "hedef", "kenet", "target" -> {
                if (mine == null) { say(me, "Bir partide değilsin.", NamedTextColor.RED); break; }
                if (args.length < 2) {
                    UUID cur = getTargetOf(me.getUniqueId());
                    if (cur != null) toggleTarget(me, cur);
                    else say(me, "Kullanım: /parti hedef <oyuncu> (ya da partideki birine çömelip sağ tıkla)", NamedTextColor.YELLOW);
                    break;
                }
                UUID tid = null;
                for (UUID id : mine.members) {
                    String n = Bukkit.getOfflinePlayer(id).getName();
                    if (n != null && n.equalsIgnoreCase(args[1])) tid = id;
                }
                if (tid == null || tid.equals(me.getUniqueId())) { say(me, "Partide böyle bir oyuncu yok.", NamedTextColor.RED); break; }
                toggleTarget(me, tid);
            }
            case "menu", "efekt" -> {
                if (mine == null) { say(me, "Bir partide değilsin.", NamedTextColor.RED); break; }
                openMenu(me, mine);
            }
            case "olustur", "create" -> {
                if (mine != null) { say(me, "Zaten bir partidesin.", NamedTextColor.RED); break; }
                create(me);
                say(me, "Parti kuruldu. /parti davet <oyuncu> ile arkadaşlarını çağır.", NamedTextColor.GREEN);
            }
            case "davet", "invite" -> {
                if (args.length < 2) { say(me, "Kullanım: /parti davet <oyuncu>", NamedTextColor.RED); break; }
                if (mine != null && !mine.leader.equals(me.getUniqueId())) {
                    say(me, "Sadece parti lideri davet edebilir.", NamedTextColor.RED);
                    break;
                }
                if (mine != null && mine.members.size() >= maxSize) {
                    say(me, "Parti dolu (en fazla " + maxSize + " kişi).", NamedTextColor.RED);
                    break;
                }
                Player t = Bukkit.getPlayerExact(args[1]);
                if (t == null) { say(me, "Oyuncu çevrimiçi değil.", NamedTextColor.RED); break; }
                if (t.equals(me)) { say(me, "Kendini davet edemezsin.", NamedTextColor.RED); break; }
                if (byPlayer.containsKey(t.getUniqueId())) {
                    say(me, t.getName() + " zaten bir partide.", NamedTextColor.RED);
                    break;
                }
                if (!compatible(me.getUniqueId(), t.getUniqueId())) {
                    say(me, "Farklı ırktaki oyuncularla parti kuramazsın.", NamedTextColor.RED);
                    break;
                }
                if (mine == null) mine = create(me);
                invites.put(t.getUniqueId(), me.getUniqueId());
                inviteExpiry.put(t.getUniqueId(), System.currentTimeMillis() + 60_000L);
                say(me, t.getName() + " davet edildi.", NamedTextColor.GREEN);
                t.sendMessage(Component.text("[Parti] ", NamedTextColor.GREEN)
                        .append(Component.text(me.getName() + " seni partiye çağırıyor. ", NamedTextColor.YELLOW))
                        .append(Component.text("[KABUL]", NamedTextColor.GREEN)
                                .clickEvent(ClickEvent.runCommand("/parti kabul")))
                        .append(Component.text(" "))
                        .append(Component.text("[RED]", NamedTextColor.RED)
                                .clickEvent(ClickEvent.runCommand("/parti reddet"))));
            }
            case "kabul", "accept" -> {
                UUID lid = invites.get(me.getUniqueId());
                Long exp = inviteExpiry.get(me.getUniqueId());
                if (lid == null || exp == null || System.currentTimeMillis() > exp) {
                    say(me, "Bekleyen davetin yok.", NamedTextColor.RED);
                    break;
                }
                invites.remove(me.getUniqueId());
                inviteExpiry.remove(me.getUniqueId());
                if (mine != null) { say(me, "Önce mevcut partinden ayrıl.", NamedTextColor.RED); break; }
                Party target = byPlayer.get(lid);
                if (target == null) { say(me, "Parti artık yok.", NamedTextColor.RED); break; }
                if (target.members.size() >= maxSize) { say(me, "Parti dolu.", NamedTextColor.RED); break; }
                if (!compatible(me.getUniqueId(), target.leader)) {
                    say(me, "Bu partinin ırkı seninkinden farklı.", NamedTextColor.RED);
                    break;
                }
                target.members.add(me.getUniqueId());
                byPlayer.put(me.getUniqueId(), target);
                tell(target, me.getName() + " partiye katıldı. (" + target.members.size() + "/" + maxSize + ")");
            }
            case "reddet", "decline" -> {
                UUID lid = invites.remove(me.getUniqueId());
                inviteExpiry.remove(me.getUniqueId());
                if (lid == null) { say(me, "Bekleyen davetin yok.", NamedTextColor.RED); break; }
                Player l = Bukkit.getPlayer(lid);
                if (l != null) say(l, me.getName() + " daveti reddetti.", NamedTextColor.GRAY);
                say(me, "Daveti reddettin.", NamedTextColor.GRAY);
            }
            case "ayril", "leave" -> {
                if (mine == null) { say(me, "Bir partide değilsin.", NamedTextColor.RED); break; }
                leave(me.getUniqueId(), "partiden ayrıldı.");
                say(me, "Partiden ayrıldın.", NamedTextColor.GRAY);
            }
            case "at", "kick" -> {
                if (mine == null || !mine.leader.equals(me.getUniqueId())) {
                    say(me, "Sadece parti lideri atabilir.", NamedTextColor.RED);
                    break;
                }
                if (args.length < 2) { say(me, "Kullanım: /parti at <oyuncu>", NamedTextColor.RED); break; }
                UUID tid = null;
                for (UUID id : mine.members) {
                    String n = Bukkit.getOfflinePlayer(id).getName();
                    if (n != null && n.equalsIgnoreCase(args[1])) tid = id;
                }
                if (tid == null || tid.equals(me.getUniqueId())) {
                    say(me, "Partide böyle bir oyuncu yok.", NamedTextColor.RED);
                    break;
                }
                Player kicked = Bukkit.getPlayer(tid);
                leave(tid, "partiden atıldı.");
                if (kicked != null) say(kicked, "Partiden atıldın.", NamedTextColor.RED);
            }
            case "lider", "promote" -> {
                if (mine == null || !mine.leader.equals(me.getUniqueId())) {
                    say(me, "Sadece parti lideri devredebilir.", NamedTextColor.RED);
                    break;
                }
                if (args.length < 2) { say(me, "Kullanım: /parti lider <oyuncu>", NamedTextColor.RED); break; }
                UUID tid = null;
                for (UUID id : mine.members) {
                    String n = Bukkit.getOfflinePlayer(id).getName();
                    if (n != null && n.equalsIgnoreCase(args[1])) tid = id;
                }
                if (tid == null) { say(me, "Partide böyle bir oyuncu yok.", NamedTextColor.RED); break; }
                mine.leader = tid;
                tell(mine, args[1] + " yeni parti lideri.");
            }
            case "dagit", "disband" -> {
                if (mine == null || !mine.leader.equals(me.getUniqueId())) {
                    say(me, "Sadece parti lideri dağıtabilir.", NamedTextColor.RED);
                    break;
                }
                tell(mine, "Parti dağıtıldı.");
                for (UUID id : new ArrayList<>(mine.members)) byPlayer.remove(id);
            }
            case "liste", "list" -> {
                if (mine == null) { say(me, "Bir partide değilsin.", NamedTextColor.RED); break; }
                StringBuilder sb = new StringBuilder();
                for (UUID id : mine.members) {
                    String n = Bukkit.getOfflinePlayer(id).getName();
                    if (sb.length() > 0) sb.append(", ");
                    sb.append(n != null ? n : "?");
                    if (id.equals(mine.leader)) sb.append(" ★");
                }
                say(me, "Üyeler (" + mine.members.size() + "/" + maxSize + "): " + sb, NamedTextColor.YELLOW);
            }
            default -> {
                say(me, "/parti olustur | davet <oyuncu> | kabul | reddet | ayril | liste", NamedTextColor.YELLOW);
                say(me, "Lider: /parti at <oyuncu> | lider <oyuncu> | dagit", NamedTextColor.GRAY);
            }
        }
        return true;
    }

    @Override
    public List<String> onTabComplete(CommandSender s, Command c, String l, String[] a) {
        List<String> out = new ArrayList<>();
        if (a.length == 1) {
            for (String x : List.of("menu", "hedef", "olustur", "davet", "kabul", "reddet", "ayril", "liste", "at", "lider", "dagit")) {
                if (x.startsWith(a[0].toLowerCase(Locale.ROOT))) out.add(x);
            }
        } else if (a.length == 2 && List.of("davet", "at", "lider", "hedef").contains(a[0].toLowerCase(Locale.ROOT))) {
            for (Player p : Bukkit.getOnlinePlayers()) {
                if (p.getName().toLowerCase(Locale.ROOT).startsWith(a[1].toLowerCase(Locale.ROOT))) out.add(p.getName());
            }
        }
        return out;
    }
}
